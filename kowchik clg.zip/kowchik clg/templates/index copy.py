<!DOCTYPE html>
<html>
<head>
    <title>Diabetes Prediction</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #0000FF;
            margin: 0;
            padding: 0;
        }

        h1 {
            color: #333;
            text-align: center;
            margin-top: 20px;
        }

        form {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .error {
            color: red;
        }

        .success {
            color: green;
        }
    </style>
    <script>
        function validateForm() {
            var pregnancies = document.getElementById('pregnancies').value;
            var glucose = document.getElementById('glucose').value;
            var bloodPressure = document.getElementById('blood_pressure').value;
            var skinThickness = document.getElementById('skin_thickness').value;
            var insulin = document.getElementById('insulin').value;
            var bmi = document.getElementById('bmi').value;
            var diabetesPedigreeFunction = document.getElementById('diabetes_pedigree_function').value;
            var age = document.getElementById('age').value;

            // Check if any field is empty
            if (pregnancies == "" || glucose == "" || bloodPressure == "" || skinThickness == "" || insulin == "" || bmi == "" || diabetesPedigreeFunction == "" || age == "") {
                alert("All fields must be filled out");
                return false;
            }

            // Check if input is a number
            if (isNaN(pregnancies) || isNaN(glucose) || isNaN(bloodPressure) || isNaN(skinThickness) || isNaN(insulin) || isNaN(bmi) || isNaN(diabetesPedigreeFunction) || isNaN(age)) {
                alert("All fields must be numeric");
                return false;
            }

            return true;
        }
    </script>
</head>
<body>
    <h1>Diabetes Prediction</h1>
    <form method="post" onsubmit="return validateForm()">
        <label for="pregnancies">Pregnancies:</label>
        <input type="text" id="pregnancies" name="pregnancies"><br>

        <label for="glucose">Glucose:</label>
        <input type="text" id="glucose" name="glucose"><br>

        <label for="blood_pressure">Blood Pressure:</label>
        <input type="text" id="blood_pressure" name="blood_pressure"><br>

        <label for="skin_thickness">Skin Thickness:</label>
        <input type="text" id="skin_thickness" name="skin_thickness"><br>

        <label for="insulin">Insulin:</label>
        <input type="text" id="insulin" name="insulin"><br>

        <label for="bmi">BMI:</label>
        <input type="text" id="bmi" name="bmi"><br>

        <label for="diabetes_pedigree_function">Diabetes Pedigree Function:</label>
        <input type="text" id="diabetes_pedigree_function" name="diabetes_pedigree_function"><br>

        <label for="age">Age:</label>
        <input type="text" id="age" name="age"><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
