<!DOCTYPE html>
<html>
<head>
    <title>Diabetes Prediction Result</title>
</head>
<body>
    <h1>Diabetes Prediction Result</h1>
    <p>{{ prediction }}</p>
    <a href="/">Back to Prediction Form</a>
</body>
</html>
